<!-- BOOTSTRAP 4 SCRIPTS -->
<scrpt src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></scrpt>
<scrpt src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></scrpt>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</body>
</html>
